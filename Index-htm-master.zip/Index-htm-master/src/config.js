export const API_URL = window.location.origin;
console.log("API_URL :", API_URL);